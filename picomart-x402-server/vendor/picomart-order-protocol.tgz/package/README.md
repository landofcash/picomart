# @picomart/order-protocol

Shared Picomart Tempo schemas, configuration, and browser/service interfaces.

Package version: `0.1.0-tempo-agent.1`.

## Tempo entry points

- `@picomart/order-protocol/tempo`
- `@picomart/order-protocol/tempo-protocol`
- `@picomart/order-protocol/tempo-contract`
- `@picomart/order-protocol/tempo-agent`

PathUSD is the configured payment token. AlphaUSD metadata does not enable payments. Applications verify their configured chain and contract before signing.

This archive is installed through the consumer project's vendored dependency and lockfile. It includes compiled modules for its recorded version. The Picomart source repository contains application setup and development instructions.
